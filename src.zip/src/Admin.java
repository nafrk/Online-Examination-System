public class Admin {
    int id;
    String name;
    String password;
    String phone;

    public Admin(int id, String name, String password, String phone) {
        this.id = id;
        this.name = name;
        this.password = password;
        this.phone = phone;
    }
}

